<!DOCTYPE html>
<html lang="fr">
	<head>
		<meta charset="utf-8">
		<title>TP2 DECOUVERTE PHP</title>
		<link rel="stylesheet" href="TP2.css">
	</head>
	<body>
		<h1> 1 - Bonjour le monde </h1>
		<h2>Ecrire un script PHP qui affiche "Bonjour le monde"</h2>
		<?php 
			echo "Bonjour le monde<br>";
		?>
		
		
		<h1> 2 - Chaîne inversée </h1>
		<h2>Ecrire un script PHP qui inverse l'ordre d'affichage d'une chaîne de caracteres.<br>
		Utiliser la fonction mb_substr($chaine,$i,$y) permettant d'extraire une sous chaîne d'une chaîne ($chaine) à partir de la position $i de longueur $y.<br>
		Utiliser la fonction strlen($chaine) qui renvoie la longueur de la chaîne. Attention, pour la fonction mb_substr, on démarre à la position 0.
		</h2>
		<?php 
			$chaine='Je demarre de la fin.';		// Ma chaine à inverser
			$inverse="";							// Variable qui contiendra la résultat

			echo 'Chaîne de départ: ' . $chaine . "<br>";	// Envoi vers les flux html de la chaine de départ avec un retour ligne à la fin
			 
			for ($i=strlen($chaine)-1; $i>=0; $i--) // Boucle en partant de la fin
			{
			  $inverse.=mb_substr($chaine,$i,1) ;	// Concaténation dans la chaine $inverse du caractere
			}
			 
			echo 'Chaîne inversée: '. $inverse;		// Envoi vers le flux Html de la chaine constituée
		?>


		<h1> 3 - Une lettre sur deux en rouge </h1>
		<h2>Ecrire un script PHP qui affiche une chaîne de caracteres avec une lettre sur deux en rouge</h2>
		<?php 
			$chaine='Une lettre sur deux en rouge.';
			
			// Exemple 1 sans duplication de code
			for ($i=0 ; $i<=strlen($chaine)-1; $i++) {	// Boucle en partant du début
				if ($i%2==0) $maClasse="enRouge"; else $maClasse="";  //  $maClasse=Enrouge ou vide en fonction de la position
				echo '<span class="'.$maClasse.'">'.mb_substr($chaine,$i,1).'</span>';	// Ajout de la lettre avec la classe necessaire
			}
			echo "<br>";
			
			// Exemple 1 avec duplication de code
			for ($i=0 ; $i<=strlen($chaine)-1; $i++) {	// Boucle en partant du début
				if ($i%2==0){							// Si on est sur une position paire
					echo '<span class="enRouge">';		// Ajout du span avec la classe enrouge pour colorer la lettre
					echo mb_substr($chaine,$i,1);		// Ajout de la lettre
					echo '</span>';						// Fermeture du span
				} else {
					echo mb_substr($chaine,$i,1);		// Ajout de la lettre sans colorisation
				}
			}
			echo "<br>";	
		?>


		<h1> 4- Tableau aléatoire </h1>
		<h2>Ecrire un script php qui va décider de la destination de vos prochaines vacances</h2>
		Le script va constituer un tableau en mémoire du type : 
		<table>
			<tr><td class="fondGris">Clé</td><td class="fondGris">Valeur</td></tr>
			<tr><td>Rodez</td><td>http://www.ville-rodez.fr/</td></tr>
			<tr><td>Montpellier</td><td>http://www.montpellier.fr/</td></tr>
			<tr><td>Toulouse</td><td>http://www.toulouse.fr/</td></tr>
			<tr><td>Limoges</td><td>http://www.ville-limoges.fr/</td></tr>
			<tr><td>Paris</td><td>https://www.parisinfo.com/</td></tr>
		</table>
		<h2>
			A l'aide de la fonction $cle=array_rand($montableau) qui retourne la clé d'une des lignes aléatoirement, <br>
			faire un lien qui renverra vers le site de la ville de vos prochaines vacances (ouverture dans une autre fenêtre).<br>
			Exemple : Mes prochaines vacances seront à <a href="http://www.toulouse.fr/" target="_blank">Toulouse</a>
		</h2>
		
		<?php 
			// Constitution du tableau (clé = ville, valeur= url)
			$tab=array("Rodez"=>"http://www.ville-rodez.fr/","Montpellier"=>"http://www.montpellier.fr/","Toulouse"=>"http://www.toulouse.fr/","Limoges"=>"http://www.ville-limoges.fr/","Paris"=>"https://www.parisinfo.com/"); 
			
			$site=array_rand($tab); // Selection aléatoire d'une ligne du tableau. renvoit la clé 
			
			echo "Mes prochaines vacances seront à : <a href=\"$tab[$site]\" target=\"_blank\" title=\"Lien vers mes prochaines vacances\">  ".$site."</a><br>"; // Constitution de la balise a pour creer le lien
			// ou bien : 
			echo "Mes prochaines vacances seront à : <a href='$tab[$site]' target='_blank' title='Lien vers mes prochaines vacances'>  ".$site."</a><br>"; // Constitution de la balise a pour creer le lien
			// ou bien : 
			echo "Mes prochaines vacances seront à : <a href='".$tab[$site]."' target='_blank' Title='Lien vers mes prochaines vacances'>  ".$site."</a><br>"; // Constitution de la balise a pour creer le lien
			
		?> 

		
		<h1> 5 - Table de multiplication </h1>
		<h2>Ecrire un script php qui génère la table de multiplication</h2>
		<table>
			<?php 
				echo '<tr><td>X</td>'.""; 							// Premiere ligne et première cellule contenant X
				for ($i=1;$i<=9;$i++) {								// Boucle pour constituer les 9 cellules de titre
					echo '<td class="fondGris">'.($i)."</td>" ;		// Remplissage des cellules en fond gris
				}
				echo "</tr>" ;										// Fin de la première ligne
				for ($i=1;$i<=9;$i++) {								// Boucle pour les 9 lignes 
					echo '<tr><td class="fondGris">'.$i."</td>"; 	// Première cellule de chaque ligne
					for ($j=1;$j<=9;$j++) {							// Boucle pour les 9 colonnes 
						echo "<td"; 								// Début de la cellule
						if ($i==$j){echo ' class="fondGris"';}		// Mise en gris si on est sur la diagonale
						echo ">".($i*$j)."</td>" ;					// Insertion valeur calculée et fermeture cellule
					}	
					echo "</tr>";									// Fin de la ligne
				}
			?>
		</table>
		<ul>
			<li>Taille caractères par défaut : 20px</li>
			<li>Entêtes lignes et colonnes : taille caractères 25px en gras</li>
			<li>Diagonale : fond gris</li>
			<li>Style des bordures double en noir</li>
			<li>Largeur des colonnes 30px</li>
			<li>Texte centré dans les cases</li>
		</ul>
		
	</body>
</html>